﻿namespace Consoledll01
{
    partial class dlForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.executionbutton = new System.Windows.Forms.Button();
            this.inputPath = new System.Windows.Forms.TextBox();
            this.inPuthButton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // executionbutton
            // 
            this.executionbutton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.executionbutton.Location = new System.Drawing.Point(312, 194);
            this.executionbutton.Name = "executionbutton";
            this.executionbutton.Size = new System.Drawing.Size(116, 43);
            this.executionbutton.TabIndex = 1;
            this.executionbutton.Text = "出力";
            this.executionbutton.UseVisualStyleBackColor = false;
            this.executionbutton.Click += new System.EventHandler(this.executionbutton_Click);
            // 
            // inputPath
            // 
            this.inputPath.Location = new System.Drawing.Point(12, 68);
            this.inputPath.Name = "inputPath";
            this.inputPath.Size = new System.Drawing.Size(624, 22);
            this.inputPath.TabIndex = 2;
            this.inputPath.Text = "\\\\szfl12\\172000_電力システム開発技術部\\開発技術部共通\\01_共通管理\\08_勉強会\\H29(2017)\\MIT\\08_users\\konishi" +
    "\\第11回\\Consoledll01\\Consoledll01\\bin\\Debug";
            this.inputPath.TextChanged += new System.EventHandler(this.inputPath_TextChanged);
            // 
            // inPuthButton
            // 
            this.inPuthButton.Location = new System.Drawing.Point(665, 64);
            this.inPuthButton.Name = "inPuthButton";
            this.inPuthButton.Size = new System.Drawing.Size(91, 28);
            this.inPuthButton.TabIndex = 4;
            this.inPuthButton.Text = "参照";
            this.inPuthButton.UseVisualStyleBackColor = true;
            this.inPuthButton.Click += new System.EventHandler(this.inPuthButton_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 123);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(624, 22);
            this.textBox1.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(665, 118);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 30);
            this.button1.TabIndex = 6;
            this.button1.Text = "参照";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // dlForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(812, 330);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.inPuthButton);
            this.Controls.Add(this.inputPath);
            this.Controls.Add(this.executionbutton);
            this.Name = "dlForm";
            this.Text = "dlForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button executionbutton;
        private System.Windows.Forms.TextBox inputPath;
        private System.Windows.Forms.Button inPuthButton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
    }
}