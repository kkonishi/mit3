﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Consoledll01
{
    public partial class dlForm : Form
    {
        public dlForm()
        {
            InitializeComponent();
        }


        //フォルダ選択のダイアログを表示
        private string DisplaynDialog(string path)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            //上部に表示する説明テキストを指定する           
            fbd.Description = "パスを指定してください";
            //最初に選択するフォルダを指定する            
            fbd.SelectedPath = path;
            // FolderBrowserDialogを表示
            if (fbd.ShowDialog() != DialogResult.OK)
            {
                return path;
            }
            return fbd.SelectedPath;
        }


        [System.Runtime.InteropServices.DllImport("Consoledll.dll")]
        static extern void Execution(string inPuth);

        private void inPuthButton_Click(object sender, EventArgs e)
        {
            //フォルダ選択ダイアログを表示
            inputPath.Text = DisplaynDialog(inputPath.Text);
        }

        private void executionbutton_Click(object sender, EventArgs e)
        {
            string inPuth = inputPath.Text;
            // C++の呼び出し
            Execution(inPuth);
        }

        private void inputPath_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
