﻿// Consoledll.cpp : DLL アプリケーション用にエクスポートされる関数を定義します。
//

#include "stdafx.h"
#include <stdio.h> 
#include <stdlib.h> 
#include <time.h> 
#include <string> 
#include <iostream> 



extern "C"
{
	void Execution()
	{
		int main(void);
		{
			int s;

			/* 乱数の種を初期化 */
			srand(time(NULL));

			/* 1 〜 10 のランダムな数 */
			s = rand() % 10 + 1;

			if (1 <= s && s <= 2) {

				// メッセージボックスに［OK］プッシュボタンだけを表示します。
				MessageBox(NULL, L"大凶", L"おみくじ", MB_OK);
				

			}else if (3 <= s && s <= 4) {

				// メッセージボックスに［OK］プッシュボタンだけを表示します。
				MessageBox(NULL, L"末吉", L"おみくじ", MB_OK);
			
			}else if (5 <= s && s <= 7) {

				// メッセージボックスに［OK］プッシュボタンだけを表示します。
				MessageBox(NULL, L"吉", L"おみくじ", MB_OK);

			}else if (8 <= s && s <= 9) {

				// メッセージボックスに［OK］プッシュボタンだけを表示します。
				MessageBox(NULL, L"中吉", L"おみくじ", MB_OK);
			
			}else {
				// メッセージボックスに［OK］プッシュボタンだけを表示します。
				MessageBox(NULL, L"大吉", L"おみくじ", MB_OK);

			}


		}
	}

}
